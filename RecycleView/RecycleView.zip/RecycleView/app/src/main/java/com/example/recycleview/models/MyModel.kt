package com.example.recycleview.models

class MyModel {
    var iconsCard: Int?
    var textCard: String?

    constructor(iconsCard:Int?, textCard: String?){
        this.iconsCard = iconsCard
        this.textCard = textCard
    }
}